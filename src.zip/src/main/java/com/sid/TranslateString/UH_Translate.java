package com.sid.TranslateString;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.Map;
import com.google.cloud.translate.Translate;
import com.google.cloud.translate.TranslateOptions;
import com.google.cloud.translate.Translation;
import com.google.cloud.translate.Translate.TranslateOption;

public class UH_Translate {
	private static UH_Translate instance = new UH_Translate();
	private Map<String, String> Environment;
	private String SourceLanguage;
	private String TargetLanguage;
	private String Text;
	private Translate translate;
	private Translation translation;

	public static UH_Translate getInstance() {
		return instance;
	}

	private UH_Translate() {
		// Default Constructor
	}

	private UH_Translate(String Text, String SourceLanguage, String TargetLanguage) {
		this(Text, SourceLanguage, TargetLanguage, null);
	}

	private UH_Translate(String Text, String SourceLanguage, String TargetLanguage, Map<String, String> Environment) {
		this.Text = Text;
		this.SourceLanguage = SourceLanguage;
		this.TargetLanguage = TargetLanguage;
		this.Environment = Environment;
	}

	public void setParameters(String Text, String SourceLanguage, String TargetLanguage) {
		setParameters(Text, SourceLanguage, TargetLanguage, null);
	}

	public void setParameters(String Text, String SourceLanguage, String TargetLanguage, Map<String, String> Environment) {
		this.Text = Text;
		this.SourceLanguage = SourceLanguage;
		this.TargetLanguage = TargetLanguage;
		this.Environment = Environment;
	}

	public void init() throws Exception {
		// Instantiates a client
		if (this.Environment.size() > 0)
			this.setEnv(this.Environment);
		this.translate = TranslateOptions.getDefaultInstance().getService();
	}

	public String getTranslatedText() {
		this.translation = translate.translate(this.Text, TranslateOption.sourceLanguage(this.SourceLanguage), TranslateOption.targetLanguage(this.TargetLanguage));
		return translation.getTranslatedText();
	}

	public Map<String, String> getEnvironment() {
		return Environment;
	}

	private void setEnvironment(Map<String, String> environment) {
		Environment = environment;
	}

	public String getSourceLanguage() {
		return SourceLanguage;
	}

	public void setSourceLanguage(String sourceLanguage) {
		SourceLanguage = sourceLanguage;
	}

	public String getTargetLanguage() {
		return TargetLanguage;
	}

	public void setTargetLanguage(String targetLanguage) {
		TargetLanguage = targetLanguage;
	}

	public String getText() {
		return Text;
	}

	public void setText(String text) {
		Text = text;
	}

	public Translation getTranslation() {
		return translation;
	}

	public void setTranslation(Translation translation) {
		this.translation = translation;
	}

	private static void setEnv(Map<String, String> newenv) throws Exception {
		try {
			Class<?> processEnvironmentClass = Class.forName("java.lang.ProcessEnvironment");
			Field theEnvironmentField = processEnvironmentClass.getDeclaredField("theEnvironment");
			theEnvironmentField.setAccessible(true);
			Map<String, String> env = (Map<String, String>) theEnvironmentField.get(null);
			env.putAll(newenv);
			Field theCaseInsensitiveEnvironmentField = processEnvironmentClass.getDeclaredField("theCaseInsensitiveEnvironment");
			theCaseInsensitiveEnvironmentField.setAccessible(true);
			Map<String, String> cienv = (Map<String, String>) theCaseInsensitiveEnvironmentField.get(null);
			cienv.putAll(newenv);
		} catch (NoSuchFieldException e) {
			Class[] classes = Collections.class.getDeclaredClasses();
			Map<String, String> env = System.getenv();
			for (Class cl : classes) {
				if ("java.util.Collections$UnmodifiableMap".equals(cl.getName())) {
					Field field = cl.getDeclaredField("m");
					field.setAccessible(true);
					Object obj = field.get(env);
					Map<String, String> map = (Map<String, String>) obj;
					map.clear();
					map.putAll(newenv);
				}
			}
		}
	}

}
