package TranslateLanguage.LanguageProject;

import java.util.HashMap;
import java.util.Map;

import com.sid.TranslateString.UH_Translate;

public class UseTranslation {

//	String text = "Hello My name Ahmad Sayeed";
	String text = "\n" + "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">\n" + "<html><head>\n" + "<title>404 Not Found</title>\n" + "</head><body>\n" + "<h1>Not Found</h1>\n"
			+ "<p>The requested URL /myProject/ was not found on this server.</p>\n" + "<hr>\n" + "<address>Apache/2.4.29 (Ubuntu) Server at localhost Port 80</address>\n" + "</body></html>\n" + "";
	String sourceLanguage = "en";
	String targetLanaguage = "ru";

	public static void main(String[] args) throws Exception {
		new UseTranslation().run();

	}

	private void run() throws Exception {
		Map<String, String> environment = new HashMap<String, String>();
		environment.put("GOOGLE_APPLICATION_CREDENTIALS", "/home/opuser/WorkPlace/GitHub/LanguageProject/My First Project-365b2e347507.json");
		String ruString = this.UH_StringTranslate(text, sourceLanguage, targetLanaguage, environment);
		System.out.println(ruString);

	}

	public String UH_StringTranslate(String text, String sourceLanguage, String targetLanaguage, Map<String, String> environment) throws Exception {
		UH_Translate uh_Translate = UH_Translate.getInstance();
		uh_Translate.setParameters(text, sourceLanguage, targetLanaguage, environment);
		uh_Translate.init();
		return uh_Translate.getTranslatedText();
	}
}

/**
 * Add Blogger, Wordpress, Medium on SMO_STTAUS Sheet starts from posts_id 0;
 * Need to fetch content from DB
 * Need to break the content from module by given identifier. 
 * DONE: It just happening: How to get data from Html by paragraph, translate them and merge them again as Html.
 * Add English version link on it.
 * Paste as it the translate completes.
 */
