package TranslateLanguage.LanguageProject;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.google.cloud.translate.Translate;
import com.google.cloud.translate.Translate.TranslateOption;
import com.google.cloud.translate.TranslateOptions;
import com.google.cloud.translate.Translation;

/**
 * Hello world!
 *
 */
public class App {
	protected static void setEnv(Map<String, String> newenv) throws Exception {
		try {
			Class<?> processEnvironmentClass = Class.forName("java.lang.ProcessEnvironment");
			Field theEnvironmentField = processEnvironmentClass.getDeclaredField("theEnvironment");
			theEnvironmentField.setAccessible(true);
			Map<String, String> env = (Map<String, String>) theEnvironmentField.get(null);
			env.putAll(newenv);
			Field theCaseInsensitiveEnvironmentField = processEnvironmentClass
					.getDeclaredField("theCaseInsensitiveEnvironment");
			theCaseInsensitiveEnvironmentField.setAccessible(true);
			Map<String, String> cienv = (Map<String, String>) theCaseInsensitiveEnvironmentField.get(null);
			cienv.putAll(newenv);
		} catch (NoSuchFieldException e) {
			Class[] classes = Collections.class.getDeclaredClasses();
			Map<String, String> env = System.getenv();
			for (Class cl : classes) {
				if ("java.util.Collections$UnmodifiableMap".equals(cl.getName())) {
					Field field = cl.getDeclaredField("m");
					field.setAccessible(true);
					Object obj = field.get(env);
					Map<String, String> map = (Map<String, String>) obj;
					map.clear();
					map.putAll(newenv);
				}
			}
		}
	}

	public static void main(String... args) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("GOOGLE_APPLICATION_CREDENTIALS",
				"/home/opuser/WorkPlace/GitHub/LanguageProject/My First Project-365b2e347507.json");
		setEnv(map);
		// Instantiates a client
		Translate translate = TranslateOptions.getDefaultInstance().getService();

		// The text to translate
		String text = getString();

		// Translates some text into Russian
		Translation translation = translate.translate(text, TranslateOption.sourceLanguage("en"),
				TranslateOption.targetLanguage("ru"));

		System.out.printf("Text: %s%n", text);
		System.out.printf("Translation: %s%n", translation.getTranslatedText());
	}

	private static String getString() {
		return "Two third-party Facebook apps dataset were exposing user’s personal records on an open Amazon cloud server. This left billions of data of Facebook users openly available said the researchers of UpGuard a security firm.\n"
				+ "\n"
				+ "The apps reported was “Cultura Colectiva”-a Mexican media company and the other one is “At the Pool”. While the information was leaked from both the apps, but the larger breach was Cultura Colectiva dataset that has the 146GB of dataset including 540 million records of Facebook users. The information contained the user activity, comments, likes, Facebook account names, and IDs.\n"
				+ "\n"
				+ "Another app called “At the Pool” also exposed significant amount of sensitive data of Facebook users. It exposed the 22,000 passwords used for the app rather than the Facebook itself. But still it is considered as risky, as it can be used to anonymously login to the app and retrieve other sensitive details.\n"
				+ "\n"
				+ "Many time people use a single password to various accounts, thus it can ring the bell for other frauds. The dataset of “At the Pool” was exposed through Amazon S3 bucket.\n"
				+ "\n"
				+ "The researchers said that, it is still not known to when exactly the data was exposed publicly. And if the data was obtained from the Amazon cloud servers by anyone.\n"
				+ "\n" + "UpGuard Researchers Addressed The Issue\n"
				+ "The researchers said that the “Cultura Colectiva” dataset breach was first notified through email on 10th jan, 2019. Another email was sent to the team on 14th of jan. But they got no response.\n"
				+ "\n"
				+ "Researchers added that they also notified the Amazon WEb Services on 28th january 2019 about it. As the data was stored within the Amazon’s S3 cloud storage service.\n"
				+ "\n"
				+ "They got a response from the Amazon Web Services on 1st of February stating that “the bucket’s owner was made aware of the exposure”.\n"
				+ "\n"
				+ "When February 21st rolled around and the data was still not secured, we again sent an email to Amazon Web Services. AWS again responded on that same day stating they would look into further potential ways to handle the situation. It was not until the morning of April 3rd, 2019, after Facebook was contacted by Bloomberg for comment, that the database backup, inside an AWS S3 storage bucket titled “cc-datalake,” was finally secured.\n"
				+ "\n"
				+ "As far as the dataset of “At the Pool” app concerned, it had been removed as soon the Facebook was contacted. Although, the app is not active since 2014 and all the accounts of the app is now shutdown.\n"
				+ "\n" + "A spokesperson from the Facebook said that-\n" + "\n"
				+ "“Facebook’s policies prohibit storing Facebook information in a public database. ” “Once alerted to the issue, we worked with Amazon to take down the databases. We are committed to working with the developers on our platform to protect people’s data.”\n"
				+ "\n"
				+ "In recent times, Facebook had received setbacks in terms of data privacy and security. There were various Facebook data breaches and scams that haunted the security of Facebook. Although, Facebook is working on restricting the third-party apps to harvest the user’s personal information.\n"
				+ "\n"
				+ "Even if the dataset exposed publicly might be a mistake, but still it concerns the user. It raises the issue of Facebook privacy and data shared through Facebook apps.";
	}
}
